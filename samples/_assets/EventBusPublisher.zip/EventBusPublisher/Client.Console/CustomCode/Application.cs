﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Primavera.Hydrogen;
using Primavera.Hydrogen.Rest.Client;

namespace Primavera.Lithium.EventBusPublisher.Client.Console
{
    [SuppressMessage("StyleCop.CSharp.DocumentationRules", "SA1601:Partial elements should be documented")]
    internal partial class Application
    {
        #region Protected Methods

        /// <inheritdoc />
        protected override void PrintCustomMenuOptions()
        {
            ConsoleHelper.WriteLine("1. Publish simple event.");
        }

        /// <inheritdoc />
        protected override async Task<bool> HandleCustomMenuOptionsAsync(ConsoleKeyInfo key)
        {
            switch (key.Key)
            {
                case ConsoleKey.D1:
                case ConsoleKey.NumPad1:
                    await this.PublishSimpleEventAsync().ConfigureAwait(false);
                    return true;
                default:
                    return true;
            }
        }

        #endregion

        #region Private Methods

        [SuppressMessage("Design", "CA1031:Do not catch general exception types", Justification = "Required by design.")]
        private async Task PublishSimpleEventAsync()
        {
            // Call the Web API

            ConsoleHelper.WriteLine();
            ConsoleHelper.WriteInformationLine("Calling the Web API...");

            try
            {
                ServiceOperationResult result = await this.Client.Publish
                    .PublishSimpleEventAsync()
                    .ConfigureAwait(false);

                ConsoleHelper.WriteInformationLine("Web API succeeded.");
            }
            catch (ServiceException ex)
            {
                this.WriteServiceException(ex);
            }
            catch (Exception ex)
            {
                this.WriteException(ex);
            }
        }

        #endregion
    }
}
