﻿# <a name="root"></a>PRIMAVERA Lithium Event Bus Publisher Service (EBP) Client Library

Allows publishing events to Event Bus.

## Service Client

| Class | Description |
| - | - |
| [`EventBusPublisherClient`](#EventBusPublisherClient) | The entry point of the Event Bus Publisher Service client library. |

## Operations

| Class | Name | Description |
| - | - | - |
| [`Publish`](#PublishOperations) | Publish | Provides operations to publish events to Event Bus. |

## Models

The client library has no models.

## Enumerations

The client library has no enumerations.

## Reference

### Service Client Classes

#### <a name="EventBusPublisherClient"></a>`EventBusPublisherClient`

- Namespace: `Primavera.Lithium.EventBusPublisher`
- Inheritance: `EventBusPublisherClientBase` (`ServiceClient<EventBusPublisherClientBase>`)

##### Constructors

###### EventBusPublisherClient(Uri, ServiceClientCredentials)

| Parameter | Type | Description |
| - | - | - |
| `baseUri` | `Uri` | The base URI of the service. |
| `credentials` | `ServiceClientCredentials` | The credentials that should be used to access the service. |

###### EventBusPublisherClient(Uri, ServiceClientCredentials, HttpMessageHandler)

| Parameter | Type | Description |
| - | - | - |
| `baseUri` | `Uri` | The base URI of the service. |
| `credentials` | `ServiceClientCredentials` | The credentials that should be used to access the service. |
| `handler` | `HttpMessageHandler` | The root message handler. |

###### EventBusPublisherClient(Uri, ServiceClientCredentials, HttpMessageHandler, bool)

| Parameter | Type | Description |
| - | - | - |
| `baseUri` | `Uri` | The base URI of the service. |
| `credentials` | `ServiceClientCredentials` | The credentials that should be used to access the service. |
| `handler` | `HttpMessageHandler` | The root message handler. |
| `disposeHandler` | `bool` | True if the inner handler should be disposed of, false if the inner handler is intended to be reused. |

###### EventBusPublisherClient(Uri, AuthenticationCallback)

| Parameter | Type | Description |
| - | - | - |
| `baseUri` | `Uri` | The base URI of the service. |
| `callback` | `AuthenticationCallback` | The callback that will be invoked during authentication to get the access token. |

###### EventBusPublisherClient(Uri, AuthenticationCallback, HttpMessageHandler)

| Parameter | Type | Description |
| - | - | - |
| `baseUri` | `Uri` | The base URI of the service. |
| `callback` | `AuthenticationCallback` | The callback that will be invoked during authentication to get the access token. |
| `handler` | `HttpMessageHandler` | The root message handler. |

###### EventBusPublisherClient(Uri, AuthenticationCallback, HttpMessageHandler, bool)

| Parameter | Type | Description |
| - | - | - |
| `baseUri` | `Uri` | The base URI of the service. |
| `callback` | `AuthenticationCallback` | The callback that will be invoked during authentication to get the access token. |
| `handler` | `HttpMessageHandler` | The root message handler. |
| `disposeHandler` | `bool` | True if the inner handler should be disposed of, false if the inner handler is intended to be reused. |

##### Properties

| Property | Type | Description |
| - | - | - |
| `AcceptLanguage` | `string` | Gets or sets the preferred language for the response. |

##### Methods

###### SetRetryPolicy(RetryPolicy

Sets the retry policy.

| Parameter | Type | Description |
| - | - | - |
| `retryPolicy` | `RetryPolicy` | The new retry policy. |

###### SetUserAgent(string, string, string

Sets the user agent header when making requests to the service.

| Parameter | Type | Description |
| - | - | - |
| `productName` | `string` | The product name. |
| `version` | `string` | The version. |
| `info` | `string` | Additional information. |

##### Example

```csharp
Uri address = new Uri("[service-address]");

using EventBusPublisherClient client = new EventBusPublisherClient(
    new Uri(address),
    ClientCredentials.NoCredentials);
```

[^ Back to top](#root)

### Operations Classes

#### <a name="PublishOperations"></a>`PublishOperations`

Provides operations to publish events to Event Bus.

- Namespace: `Primavera.Lithium.EventBusPublisher`
- Inheritance: `PublishOperationsBase` (`IPublishOperations`)

##### Methods

##### `PublishSimpleEventAsync()`

Publishes a simple event to Event Bus.

```csharp
public async Task<ServiceOperationResult> PublishSimpleEventAsync(CancellationToken cancellationToken = default);
```

###### Parameters

The operation has no parameters.


###### Returns

| Return Type | Description |
| - | - | - | - |
| None | The operation has no return value. |


###### Status Codes

| Status Code | Description |
| - | - | - | - |
| `HttpStatusCode.NoContent` | Success. |
| `HttpStatusCode.BadRequest` | Failure: the request is invalid.|

> The operation will raise `ServiceException` for any failure status code. The exception may include a body with a `ServiceError` depending on the status code.


[^ Back to top](#root)

