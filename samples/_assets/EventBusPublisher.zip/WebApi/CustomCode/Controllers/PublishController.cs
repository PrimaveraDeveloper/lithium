﻿using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;
using Primavera.Hydrogen.EventBus;
using Primavera.Hydrogen.EventBus.Azure.Entities;

namespace Primavera.Lithium.EventBusPublisher.WebApi.Controllers
{
    [SuppressMessage("StyleCop.CSharp.DocumentationRules", "SA1601:Partial elements should be documented")]
    public partial class PublishController
    {
        #region Private Properties

        private IEventBusService EventBusService
        {
            get
            {
                return this.HttpContext.RequestServices.GetRequiredService<IEventBusService>();
            }
        }

        #endregion

        #region Protected Methods

        /// <inheritdoc />
        protected override async Task<IActionResult> PublishSimpleEventCoreAsync()
        {
            // Build the event

            IEventBusEvent<string> evt = new AzureEventBusEvent<string>()
            {
                Body = "This is a simple event"
            };

            // Publish the event

            await this.EventBusService.PublishAsync(
                "sample", 
                evt)
                .ConfigureAwait(false);

            // Done

            return this.NoContent();
        }

        #endregion
    }
}
