﻿using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Primavera.Hydrogen.AspNetCore.Webhooks;

namespace Primavera.Lithium.IdentityServerWebhooksReceiver.WebApi.Controllers
{
    [SuppressMessage("StyleCop.CSharp.DocumentationRules", "SA1601:Partial elements should be documented")]
    public partial class WebhookCallbacksController
    {
        #region Protected Methods

        /// <inheritdoc />
        protected override async Task<IActionResult> IdentityResourceCallbackCoreAsync()
        {
            WebhookHeaders headers = this.Request.GetWebhookHeaders();

            string payload = await this.Request.ReadWebhookPayloadAsStringAsync().ConfigureAwait(false);

            if (!headers.IsSignatureValid("IDWHR-SECRET", payload))
            {
                this.Logger.LogError($"Webhook signature '{headers.Signature}' is invalid.");
                return this.BadRequest();
            }

            this.Logger.LogInformation($"Received Identity Resource webhook.");
            this.Logger.LogInformation($"Webhook headers: '{headers}'.");
            this.Logger.LogInformation($"Webhook payload: '{payload}'.");

            return this.Ok();
        }

        #endregion
    }
}
