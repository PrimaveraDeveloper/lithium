﻿using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace Primavera.Lithium.IdentityServerWebhooksReceiver.WebApi.Controllers
{
    [SuppressMessage("StyleCop.CSharp.DocumentationRules", "SA1601:Partial elements should be documented")]
    public partial class MonitoringController
    {
        #region Public Methods

        /// <inheritdoc />
        public override Task<IActionResult> ProbeAsync()
        {
            return Task.FromResult<IActionResult>(
                this.Ok("OK"));
        }

        /// <inheritdoc />
        public override Task<IActionResult> DiagnosticsAsync()
        {
            return this.ProbeAsync();
        }

        #endregion
    }
}
