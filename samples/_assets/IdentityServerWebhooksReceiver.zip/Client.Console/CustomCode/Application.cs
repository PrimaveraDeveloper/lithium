﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using Primavera.Hydrogen;
using Primavera.Hydrogen.IdentityModel.Client;
using Primavera.Hydrogen.IdentityModel.Client.Messages;
using Primavera.Hydrogen.Rest.Client;
using Primavera.Hydrogen.Rest.Client.Webhooks;
using Primavera.Hydrogen.Rest.Webhooks;

namespace Primavera.Lithium.IdentityServerWebhooksReceiver.Client.Console
{
    [SuppressMessage("StyleCop.CSharp.DocumentationRules", "SA1601:Partial elements should be documented")]
    internal sealed partial class Application
    {
        #region Constants

        private const string IdentityServer5BaseAddress = "https://localhost:10001";

        #endregion

        #region Fields

        private string fieldSubscriptionId;

        #endregion

        #region Protected Methods

        /// <inheritdoc />
        protected override void PrintCustomMenuOptions()
        {
            ConsoleHelper.WriteLine("1. Webhooks.");
        }

        /// <inheritdoc />
        protected override async Task<bool> HandleCustomMenuOptionsAsync(ConsoleKeyInfo key)
        {
            switch (key.Key)
            {
                case ConsoleKey.D1:
                case ConsoleKey.NumPad1:
                    return !await this.ShowWebhooksMenuAsync().ConfigureAwait(false);
                default:
                    return true;
            }
        }

        #endregion

        #region Private Methods

        #region Menus (Webhooks)

        [SuppressMessage("Microsoft.Maintainability", "CA1502:Avoid excessive complexity")]
        private async Task<bool> ShowWebhooksMenuAsync()
        {
            // Menu

            bool terminate = false;
            bool cont = true;
            while (cont)
            {
                ConsoleHelper.WriteLine();
                ConsoleHelper.WriteLine("========================================");
                ConsoleHelper.WriteLine("Webhooks");
                ConsoleHelper.WriteLine("========================================");
                ConsoleHelper.WriteLine();
                ConsoleHelper.WriteLine("1. Get All Subscriptions.");
                ConsoleHelper.WriteLine("2. Subscribe All Webhooks.");
                ConsoleHelper.WriteLine("3. Delete Subscription.");
                ConsoleHelper.WriteLine("9. List All Webhooks.");
                ConsoleHelper.WriteLine("<. Back.");
                ConsoleHelper.WriteLine("Q. Quit.");
                ConsoleHelper.Write(">> ");

                ConsoleKeyInfo key = ConsoleHelper.ReadKey();
                ConsoleHelper.WriteLine();

                switch (key.Key)
                {
                    case ConsoleKey.Q:
                        cont = false;
                        terminate = true;
                        break;
                    case ConsoleKey.LeftArrow:
                        cont = false;
                        break;
                    case ConsoleKey.D1:
                    case ConsoleKey.NumPad1:
                        await this.GetAllWebhookSubscriptionsAsync().ConfigureAwait(false);
                        break;
                    case ConsoleKey.D2:
                    case ConsoleKey.NumPad2:
                        await this.SubscribeAllWebhooksAsync().ConfigureAwait(false);
                        break;
                    case ConsoleKey.D3:
                    case ConsoleKey.NumPad3:
                        await this.DeleteWebhookSubscriptionAsync().ConfigureAwait(false);
                        break;
                    case ConsoleKey.D9:
                    case ConsoleKey.NumPad9:
                        await this.ListAllWebhooksAsync().ConfigureAwait(false);
                        break;
                    default:
                        break;
                }
            }

            // Result

            return terminate;
        }

        #endregion

        #region Webhooks

        [SuppressMessage("Design", "CA1031:Do not catch general exception types", Justification = "Want to print all exceptions.")]
        private async Task GetAllWebhookSubscriptionsAsync()
        {
            ConsoleHelper.WriteLine();
            ConsoleHelper.WriteLine();

            using IWebhooksSubscriptionsClient client = new WebhooksSubscriptionsClient();

            ConsoleHelper.WriteLine();
            ConsoleHelper.WriteInformationLine("Calling the Web API...");

            try
            {
                string accessToken = await RetrieveAccessTokenAsync().ConfigureAwait(false);

                GetWebhookSubscriptionsResponse response = await client.GetSubscriptionsAsync(
                    new Uri(IdentityServer5BaseAddress),
                    "IDWHR",
                    accessToken)
                    .ConfigureAwait(false);

                ConsoleHelper.WriteInformationLine("The request succeeded. See the results below.");

                Write(response);

                ConsoleHelper.WriteLine();

                WebhookSubscription subscription = response.Data?.FirstOrDefault();
                if (subscription != null)
                {
                    this.fieldSubscriptionId = subscription.SubscriptionId;
                }
            }
            catch (ServiceException ex)
            {
                this.WriteServiceException(ex);
            }
            catch (Exception ex)
            {
                ConsoleHelper.WriteErrorLine(ex);
            }
        }

        [SuppressMessage("Design", "CA1031:Do not catch general exception types", Justification = "Want to print all exceptions.")]
        private async Task SubscribeAllWebhooksAsync()
        {
            ConsoleHelper.WriteLine();
            ConsoleHelper.WriteLine();

            using IWebhooksSubscriptionsClient client = new WebhooksSubscriptionsClient();

            ConsoleHelper.WriteLine();
            ConsoleHelper.WriteInformationLine("Calling the Web API...");

            try
            {
                string accessToken = await RetrieveAccessTokenAsync().ConfigureAwait(false);

                CreateWebhookSubscriptionRequest request = new CreateWebhookSubscriptionRequest()
                {
                    ClientId = "IDWHR",
                    Secret = "IDWHR-SECRET",
                    CallbackUrl = new Uri("https://localhost:20001/api/v1/webhookcallbacks/identityresources"),
                    EventNames = new List<string>()
                    {
                        "IdentityResource_Created",
                        "IdentityResource_Updated",
                        "IdentityResource_Deleted",
                    },
                    Properties = new Dictionary<string, string>()
                    {
                        ["Property1"] = "Value1"
                    },
                    Active = true
                };

                CreateWebhookSubscriptionResponse response = await client.CreateSubscriptionAsync(
                    new Uri(IdentityServer5BaseAddress),
                    request,
                    accessToken)
                    .ConfigureAwait(false);

                ConsoleHelper.WriteInformationLine("The request succeeded. See the results below.");

                Write(response);

                ConsoleHelper.WriteLine();
            }
            catch (ServiceException ex)
            {
                this.WriteServiceException(ex);
            }
            catch (Exception ex)
            {
                ConsoleHelper.WriteErrorLine(ex);
            }
        }

        [SuppressMessage("Design", "CA1031:Do not catch general exception types", Justification = "Want to print all exceptions.")]
        private async Task DeleteWebhookSubscriptionAsync()
        {
            ConsoleHelper.WriteLine();
            ConsoleHelper.WriteLine();

            using IWebhooksSubscriptionsClient client = new WebhooksSubscriptionsClient();

            string subscriptionId = this.GetValueString("subscription id", true, this.fieldSubscriptionId);

            ConsoleHelper.WriteLine();
            ConsoleHelper.WriteInformationLine("Calling the Web API...");

            try
            {
                string accessToken = await RetrieveAccessTokenAsync().ConfigureAwait(false);

                WebhookSubscriptionResponse response = await client.DeleteSubscriptionAsync(
                    new Uri(IdentityServer5BaseAddress),
                    "IDWHR",
                    subscriptionId,
                    accessToken)
                    .ConfigureAwait(false);

                ConsoleHelper.WriteInformationLine("The request succeeded. See the results below.");

                Write(response);

                ConsoleHelper.WriteLine();

                this.fieldSubscriptionId = subscriptionId;
            }
            catch (ServiceException ex)
            {
                this.WriteServiceException(ex);
            }
            catch (Exception ex)
            {
                ConsoleHelper.WriteErrorLine(ex);
            }
        }

        [SuppressMessage("Design", "CA1031:Do not catch general exception types", Justification = "Want to print all exceptions.")]
        private async Task ListAllWebhooksAsync()
        {
            ConsoleHelper.WriteLine();
            ConsoleHelper.WriteLine();

            using IWebhooksSubscriptionsClient client = new WebhooksSubscriptionsClient();

            ConsoleHelper.WriteLine();
            ConsoleHelper.WriteInformationLine("Calling the Web API...");

            try
            {
                string accessToken = await RetrieveAccessTokenAsync().ConfigureAwait(false);

                CreateWebhookSubscriptionRequest request = new CreateWebhookSubscriptionRequest()
                {
                    ClientId = "IDWHR",
                    Secret = "IDWHR-SECRET",
                    CallbackUrl = new Uri("https://localhost:20001/api/v1/webhookcallbacks/identityresources"),
                    EventNames = new List<string>()
                    {
                        "IdentityResource_Created",
                        "IdentityResource_Updated",
                        "IdentityResource_Deleted",
                    },
                    Properties = new Dictionary<string, string>()
                    {
                        ["Property1"] = "Value1"
                    },
                    Active = true
                };

                GetWebhooksMetadataResponse response = await client.GetWebhooksMetadataAsync(
                    new Uri(IdentityServer5BaseAddress),
                    accessToken)
                    .ConfigureAwait(false);

                ConsoleHelper.WriteInformationLine("The request succeeded. See the results below.");

                Write(response);

                ConsoleHelper.WriteLine();
            }
            catch (ServiceException ex)
            {
                this.WriteServiceException(ex);
            }
            catch (Exception ex)
            {
                ConsoleHelper.WriteErrorLine(ex);
            }
        }

        #endregion

        #region Write (Webhooks)

        private static void Write(GetWebhookSubscriptionsResponse instance)
        {
            ConsoleHelper.WriteInformationLine($"{nameof(GetWebhookSubscriptionsResponse)}:");
            ConsoleHelper.WriteInformationLine($"  {nameof(GetWebhookSubscriptionsResponse.IsError)} = {instance.IsError}");
            ConsoleHelper.WriteInformationLine($"  {nameof(GetWebhookSubscriptionsResponse.HttpStatusCode)} = {instance.HttpStatusCode}");
            ConsoleHelper.WriteInformationLine($"  {nameof(GetWebhookSubscriptionsResponse.HttpReasonPhrase)} = {instance.HttpReasonPhrase}");
            ConsoleHelper.WriteInformationLine($"  {nameof(GetWebhookSubscriptionsResponse.Error)} = {instance.Error}");
            Write(instance.Data, nameof(GetWebhookSubscriptionsResponse.Data), "  ");
        }

        private static void Write(CreateWebhookSubscriptionResponse instance)
        {
            ConsoleHelper.WriteInformationLine($"{nameof(CreateWebhookSubscriptionResponse)}:");
            ConsoleHelper.WriteInformationLine($"  {nameof(CreateWebhookSubscriptionResponse.IsError)} = {instance.IsError}");
            ConsoleHelper.WriteInformationLine($"  {nameof(CreateWebhookSubscriptionResponse.HttpStatusCode)} = {instance.HttpStatusCode}");
            ConsoleHelper.WriteInformationLine($"  {nameof(CreateWebhookSubscriptionResponse.HttpReasonPhrase)} = {instance.HttpReasonPhrase}");
            ConsoleHelper.WriteInformationLine($"  {nameof(CreateWebhookSubscriptionResponse.Error)} = {instance.Error}");
            ConsoleHelper.WriteInformationLine($"  {nameof(CreateWebhookSubscriptionResponse.Data)} = {instance.Data}");
        }

        private static void Write(GetWebhooksMetadataResponse instance)
        {
            ConsoleHelper.WriteInformationLine($"{nameof(GetWebhooksMetadataResponse)}:");
            ConsoleHelper.WriteInformationLine($"  {nameof(GetWebhooksMetadataResponse.IsError)} = {instance.IsError}");
            ConsoleHelper.WriteInformationLine($"  {nameof(GetWebhooksMetadataResponse.HttpStatusCode)} = {instance.HttpStatusCode}");
            ConsoleHelper.WriteInformationLine($"  {nameof(GetWebhooksMetadataResponse.HttpReasonPhrase)} = {instance.HttpReasonPhrase}");
            ConsoleHelper.WriteInformationLine($"  {nameof(GetWebhooksMetadataResponse.Error)} = {instance.Error}");
            Write(instance.Data, nameof(GetWebhooksMetadataResponse.Data), "  ");
        }

        private static void Write(WebhookSubscriptionResponse instance)
        {
            ConsoleHelper.WriteInformationLine($"{nameof(WebhookSubscriptionResponse)}:");
            ConsoleHelper.WriteInformationLine($"  {nameof(WebhookSubscriptionResponse.IsError)} = {instance.IsError}");
            ConsoleHelper.WriteInformationLine($"  {nameof(WebhookSubscriptionResponse.HttpStatusCode)} = {instance.HttpStatusCode}");
            ConsoleHelper.WriteInformationLine($"  {nameof(WebhookSubscriptionResponse.HttpReasonPhrase)} = {instance.HttpReasonPhrase}");
            ConsoleHelper.WriteInformationLine($"  {nameof(WebhookSubscriptionResponse.Error)} = {instance.Error}");
        }

        private static void Write(IEnumerable<WebhookMetadata> instances, string title, string prefix)
        {
            ConsoleHelper.WriteInformationLine(prefix + $"{title}:");

            if (instances == null || !instances.Any())
            {
                ConsoleHelper.WriteInformationLine(prefix + "  <no data>");
                return;
            }

            foreach (WebhookMetadata instance in instances)
            {
                Write(instance, prefix + "  ");
            }
        }

        private static void Write(WebhookMetadata instance, string prefix)
        {
            ConsoleHelper.WriteInformationLine(prefix + $"{nameof(WebhookMetadata)}:");
            ConsoleHelper.WriteInformationLine(prefix + $"  {nameof(WebhookMetadata.EventName)} = {instance.EventName}");
            ConsoleHelper.WriteInformationLine(prefix + $"  {nameof(WebhookMetadata.EventDescription)} = {instance.EventDescription}");
            ConsoleHelper.WriteInformationLine(prefix + $"  {nameof(WebhookMetadata.PayloadDescription)} = {instance.PayloadDescription}");
        }

        private static void Write(IEnumerable<WebhookSubscription> instances, string title, string prefix)
        {
            ConsoleHelper.WriteInformationLine(prefix + $"{title}:");

            if (instances == null || !instances.Any())
            {
                ConsoleHelper.WriteInformationLine(prefix + "  <no data>");
                return;
            }

            foreach (WebhookSubscription instance in instances)
            {
                Write(instance, prefix + "  ");
            }
        }

        private static void Write(WebhookSubscription instance, string prefix)
        {
            ConsoleHelper.WriteInformationLine(prefix + $"{nameof(WebhookSubscription)}:");
            ConsoleHelper.WriteInformationLine(prefix + $"  {nameof(WebhookSubscription.SubscriptionId)} = {instance.SubscriptionId}");
            ConsoleHelper.WriteInformationLine(prefix + $"  {nameof(WebhookSubscription.ClientId)} = {instance.ClientId}");
            ConsoleHelper.WriteInformationLine(prefix + $"  {nameof(WebhookSubscription.Secret)} = {instance.Secret}");
            ConsoleHelper.WriteInformationLine(prefix + $"  {nameof(WebhookSubscription.CallbackUrl)} = {instance.CallbackUrl}");
            ConsoleHelper.WriteInformationLine(prefix + $"  {nameof(WebhookSubscription.Active)} = {instance.Active}");
            ConsoleHelper.WriteInformationLine(prefix + $"  {nameof(WebhookSubscription.ModifiedOn)} = {instance.ModifiedOn}");
            Write(instance.EventNames, nameof(WebhookSubscription.EventNames), prefix + "  ");
            Write(instance.Filters, nameof(WebhookSubscription.Filters), prefix + "  ");
            Write(instance.Properties, nameof(WebhookSubscription.Properties), prefix + "  ");
            Write(instance.LastRequest, prefix + "  ");
            Write(instance.LastResponse, prefix + "  ");
        }

        private static void Write(WebhookCallbackRequest instance, string prefix)
        {
            ConsoleHelper.WriteInformationLine(prefix + $"{nameof(WebhookSubscription.LastRequest)}:");

            if (instance == null)
            {
                ConsoleHelper.WriteInformationLine(prefix + $"  <no data>");
                return;
            }

            ConsoleHelper.WriteInformationLine(prefix + $"  {nameof(WebhookCallbackRequest.Status)} = {instance.Status}");
            ConsoleHelper.WriteInformationLine(prefix + $"  {nameof(WebhookCallbackRequest.EventName)} = {instance.EventName}");
            ConsoleHelper.WriteInformationLine(prefix + $"  {nameof(WebhookCallbackRequest.CallbackUrl)} = {instance.CallbackUrl}");
            ConsoleHelper.WriteInformationLine(prefix + $"  {nameof(WebhookCallbackRequest.Payload)} = {instance.Payload}");
            ConsoleHelper.WriteInformationLine(prefix + $"  {nameof(WebhookCallbackRequest.Retries)} = {instance.Retries}");
            ConsoleHelper.WriteInformationLine(prefix + $"  {nameof(WebhookCallbackRequest.NextRetry)} = {instance.NextRetry}");
            ConsoleHelper.WriteInformationLine(prefix + $"  {nameof(WebhookCallbackRequest.Timestamp)} = {instance.Timestamp}");
            Write(instance.Filters, nameof(WebhookCallbackRequest.Filters), prefix + "  ");
            Write(instance.Properties, nameof(WebhookCallbackRequest.Properties), prefix + "  ");
            Write(instance.Headers, nameof(WebhookCallbackRequest.Headers), prefix + "  ");
        }

        private static void Write(WebhookCallbackResponse instance, string prefix)
        {
            ConsoleHelper.WriteInformationLine(prefix + $"{nameof(WebhookSubscription.LastResponse)}:");

            if (instance == null)
            {
                ConsoleHelper.WriteInformationLine(prefix + $"  <no data>");
                return;
            }

            ConsoleHelper.WriteInformationLine(prefix + $"  {nameof(WebhookCallbackResponse.Code)} = {instance.Code}");
            ConsoleHelper.WriteInformationLine(prefix + $"  {nameof(WebhookCallbackResponse.Message)} = {instance.Message}");
            ConsoleHelper.WriteInformationLine(prefix + $"  {nameof(WebhookCallbackResponse.Timestamp)} = {instance.Timestamp}");
        }

        private static void Write(IEnumerable<string> instances, string title, string prefix)
        {
            ConsoleHelper.WriteInformationLine(prefix + $"{title}:");

            if (instances == null || !instances.Any())
            {
                ConsoleHelper.WriteInformationLine(prefix + "  <no data>");
                return;
            }

            foreach (string instance in instances)
            {
                ConsoleHelper.WriteInformationLine(prefix + $"  {instance}");
            }
        }

        private static void Write(IDictionary<string, string> instances, string title, string prefix)
        {
            ConsoleHelper.WriteInformationLine(prefix + $"{title}:");

            if (instances == null || !instances.Any())
            {
                ConsoleHelper.WriteInformationLine(prefix + "  <no data>");
                return;
            }

            foreach (KeyValuePair<string, string> instance in instances)
            {
                ConsoleHelper.WriteInformationLine(prefix + $"  {instance.Key} = {instance.Value}");
            }
        }

        #endregion

        #region Access Token

        private static async Task<string> RetrieveAccessTokenAsync()
        {
            // TODO change client id and secret

            using TokenClient tokenClient = new TokenClient();

            TokenResponse response = await tokenClient.GetClientCredentialsTokenAsync(
                IdentityServer5BaseAddress,
                new TokenClientOptions()
                {
                    ////ClientId = Constants.ClientId,
                    ////ClientSecret = Constants.ClientSecret
                    ClientId = "identityserver4-clientcredentials",
                    ClientSecret = "89FCD06C-8521-4E51-BA65-3EF9BDCE097F"
                },
                "identityserver4-wh")
                .ConfigureAwait(false);

            if (response.IsError)
            {
                throw new InvalidOperationException($"Could not retrieve the access token. Error: '{response.Error}'.");
            }

            return response.AccessToken;
        }

        #endregion

        #endregion
    }
}
