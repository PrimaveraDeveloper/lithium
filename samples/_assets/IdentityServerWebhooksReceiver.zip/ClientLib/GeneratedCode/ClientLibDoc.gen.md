﻿# <a name="root"></a>PRIMAVERA Lithium Identity Server Webhooks Receiver Service (IDWHR) Client Library

Receives webhooks from Identity Server.

## Service Client

| Class | Description |
| - | - |
| [`IdentityServerWebhooksReceiverClient`](#IdentityServerWebhooksReceiverClient) | The entry point of the Identity Server Webhooks Receiver Service client library. |

## Operations

| Class | Name | Description |
| - | - | - |
| [`WebhookCallbacks`](#WebhookCallbacksOperations) | Webhook Callbacks | Provides the callbacks to receive the webhooks. |

## Models

The client library has no models.

## Enumerations

The client library has no enumerations.

## Reference

### Service Client Classes

#### <a name="IdentityServerWebhooksReceiverClient"></a>`IdentityServerWebhooksReceiverClient`

- Namespace: `Primavera.Lithium.IdentityServerWebhooksReceiver`
- Inheritance: `IdentityServerWebhooksReceiverClientBase` (`ServiceClient<IdentityServerWebhooksReceiverClientBase>`)

##### Constructors

###### IdentityServerWebhooksReceiverClient(Uri, ServiceClientCredentials)

| Parameter | Type | Description |
| - | - | - |
| `baseUri` | `Uri` | The base URI of the service. |
| `credentials` | `ServiceClientCredentials` | The credentials that should be used to access the service. |

###### IdentityServerWebhooksReceiverClient(Uri, ServiceClientCredentials, HttpMessageHandler)

| Parameter | Type | Description |
| - | - | - |
| `baseUri` | `Uri` | The base URI of the service. |
| `credentials` | `ServiceClientCredentials` | The credentials that should be used to access the service. |
| `handler` | `HttpMessageHandler` | The root message handler. |

###### IdentityServerWebhooksReceiverClient(Uri, ServiceClientCredentials, HttpMessageHandler, bool)

| Parameter | Type | Description |
| - | - | - |
| `baseUri` | `Uri` | The base URI of the service. |
| `credentials` | `ServiceClientCredentials` | The credentials that should be used to access the service. |
| `handler` | `HttpMessageHandler` | The root message handler. |
| `disposeHandler` | `bool` | True if the inner handler should be disposed of, false if the inner handler is intended to be reused. |

###### IdentityServerWebhooksReceiverClient(Uri, AuthenticationCallback)

| Parameter | Type | Description |
| - | - | - |
| `baseUri` | `Uri` | The base URI of the service. |
| `callback` | `AuthenticationCallback` | The callback that will be invoked during authentication to get the access token. |

###### IdentityServerWebhooksReceiverClient(Uri, AuthenticationCallback, HttpMessageHandler)

| Parameter | Type | Description |
| - | - | - |
| `baseUri` | `Uri` | The base URI of the service. |
| `callback` | `AuthenticationCallback` | The callback that will be invoked during authentication to get the access token. |
| `handler` | `HttpMessageHandler` | The root message handler. |

###### IdentityServerWebhooksReceiverClient(Uri, AuthenticationCallback, HttpMessageHandler, bool)

| Parameter | Type | Description |
| - | - | - |
| `baseUri` | `Uri` | The base URI of the service. |
| `callback` | `AuthenticationCallback` | The callback that will be invoked during authentication to get the access token. |
| `handler` | `HttpMessageHandler` | The root message handler. |
| `disposeHandler` | `bool` | True if the inner handler should be disposed of, false if the inner handler is intended to be reused. |

##### Properties

| Property | Type | Description |
| - | - | - |
| `AcceptLanguage` | `string` | Gets or sets the preferred language for the response. |

##### Methods

###### SetRetryPolicy(RetryPolicy

Sets the retry policy.

| Parameter | Type | Description |
| - | - | - |
| `retryPolicy` | `RetryPolicy` | The new retry policy. |

###### SetUserAgent(string, string, string

Sets the user agent header when making requests to the service.

| Parameter | Type | Description |
| - | - | - |
| `productName` | `string` | The product name. |
| `version` | `string` | The version. |
| `info` | `string` | Additional information. |

##### Example

```csharp
Uri address = new Uri("[service-address]");

using IdentityServerWebhooksReceiverClient client = new IdentityServerWebhooksReceiverClient(
    new Uri(address),
    ClientCredentials.NoCredentials);
```

[^ Back to top](#root)

### Operations Classes

#### <a name="WebhookCallbacksOperations"></a>`WebhookCallbacksOperations`

Provides the callbacks to receive the webhooks.

- Namespace: `Primavera.Lithium.IdentityServerWebhooksReceiver`
- Inheritance: `WebhookCallbacksOperationsBase` (`IWebhookCallbacksOperations`)

##### Methods

##### `IdentityResourceCallbackAsync()`

The callback to receive webhooks for identity resources.

```csharp
public async Task<ServiceOperationResult> IdentityResourceCallbackAsync(CancellationToken cancellationToken = default);
```

###### Parameters

The operation has no parameters.


###### Returns

| Return Type | Description |
| - | - | - | - |
| None | The operation has no return value. |


###### Status Codes

| Status Code | Description |
| - | - | - | - |
| `HttpStatusCode.Ok` | Success. |
| `HttpStatusCode.BadRequest` | Failure: the request is invalid.|

> The operation will raise `ServiceException` for any failure status code. The exception may include a body with a `ServiceError` depending on the status code.


[^ Back to top](#root)

