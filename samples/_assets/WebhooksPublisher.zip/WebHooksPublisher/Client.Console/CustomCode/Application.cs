﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Primavera.Hydrogen;
using Primavera.Hydrogen.Rest.Client;
using Primavera.Lithium.WebhooksPublisher.Models;

namespace Primavera.Lithium.WebhooksPublisher.Client.Console
{
    [SuppressMessage("StyleCop.CSharp.DocumentationRules", "SA1601:Partial elements should be documented")]
    internal sealed partial class Application
    {
        #region Fields

        private string fieldLastCustomer;

        #endregion

        #region Protected Methods

        /// <inheritdoc />
        protected override void PrintCustomMenuOptions()
        {
            ConsoleHelper.WriteLine("1. Customers");
        }

        /// <inheritdoc />
        protected override async Task<bool> HandleCustomMenuOptionsAsync(ConsoleKeyInfo key)
        {
            switch (key.Key)
            {
                case ConsoleKey.D1:
                case ConsoleKey.NumPad1:
                    return !await this.ShowCustomersMenuAsync().ConfigureAwait(false);
                default:
                    return true;
            }
        }

        #endregion

        #region Private Methods

        #region Customers

        private async Task<bool> ShowCustomersMenuAsync()
        {
            // Menu

            bool terminate = false;
            bool cont = true;
            while (cont)
            {
                ConsoleHelper.WriteLine();
                ConsoleHelper.WriteLine("========================================");
                ConsoleHelper.WriteLine("Customers Menu");
                ConsoleHelper.WriteLine("========================================");
                ConsoleHelper.WriteLine();
                ConsoleHelper.WriteLine("1. Create Customer.");
                ConsoleHelper.WriteLine("2. Get Customer.");
                ConsoleHelper.WriteLine("3. Delete Customer.");
                ConsoleHelper.WriteLine("<. Back.");
                ConsoleHelper.WriteLine("Q. Quit.");
                ConsoleHelper.Write(">> ");

                ConsoleKeyInfo key = ConsoleHelper.ReadKey();
                ConsoleHelper.WriteLine();

                switch (key.Key)
                {
                    case ConsoleKey.Q:
                        cont = false;
                        terminate = true;
                        break;
                    case ConsoleKey.LeftArrow:
                        cont = false;
                        break;
                    case ConsoleKey.D1:
                    case ConsoleKey.NumPad1:
                        await this.CreateCustomerAsync().ConfigureAwait(false);
                        break;
                    case ConsoleKey.D2:
                    case ConsoleKey.NumPad2:
                        await this.GetCustomerAsync().ConfigureAwait(false);
                        break;
                    case ConsoleKey.D3:
                    case ConsoleKey.NumPad3:
                        await this.DeleteCustomerAsync().ConfigureAwait(false);
                        break;
                    default:
                        break;
                }
            }

            // Result

            return terminate;
        }

        [SuppressMessage("Design", "CA1031:Do not catch general exception types", Justification = "Required by design.")]
        private async Task CreateCustomerAsync()
        {
            ConsoleHelper.WriteLine();
            ConsoleHelper.WriteLine();

            // Get the customer

            CustomerData customer = new CustomerData()
            {
                Customer = this.GetValueString("customer id", this.fieldLastCustomer)
            };

            // Call the Web API

            ConsoleHelper.WriteLine();
            ConsoleHelper.WriteInformationLine("Calling the Web API...");

            try
            {
                ServiceOperationResult<string> response = await this.Client.Customers.CreateCustomerAsync(customer).ConfigureAwait(false);

                ConsoleHelper.WriteInformationLine("Web API returned the result. See below.");
                ConsoleHelper.WriteInformationLine("Customer: {0}", response.Body);

                this.fieldLastCustomer = customer.Customer;
            }
            catch (ServiceException ex)
            {
                this.WriteServiceException(ex);
            }
            catch (Exception ex)
            {
                ConsoleHelper.WriteErrorLine(ex);
            }
        }

        [SuppressMessage("Design", "CA1031:Do not catch general exception types", Justification = "Required by design.")]
        private async Task GetCustomerAsync()
        {
            ConsoleHelper.WriteLine();
            ConsoleHelper.WriteLine();

            // Get the customer

            string customer = this.GetValueString("customer id", this.fieldLastCustomer);

            // Call the Web API

            ConsoleHelper.WriteLine();
            ConsoleHelper.WriteInformationLine("Calling the Web API...");

            try
            {
                ServiceOperationResult<CustomerData> response = await this.Client.Customers.GetCustomerAsync(customer).ConfigureAwait(false);

                ConsoleHelper.WriteInformationLine("Web API returned the result. See below.");
                ConsoleHelper.WriteInformationLine("Customer: {0}", response.Body.Customer);

                this.fieldLastCustomer = customer;
            }
            catch (ServiceException ex)
            {
                this.WriteServiceException(ex);
            }
            catch (Exception ex)
            {
                ConsoleHelper.WriteErrorLine(ex);
            }
        }

        [SuppressMessage("Design", "CA1031:Do not catch general exception types", Justification = "Required by design.")]
        private async Task DeleteCustomerAsync()
        {
            ConsoleHelper.WriteLine();
            ConsoleHelper.WriteLine();

            // Get the customer

            string customer = this.GetValueString("customer id", this.fieldLastCustomer);

            // Call the Web API

            ConsoleHelper.WriteLine();
            ConsoleHelper.WriteInformationLine("Calling the Web API...");

            try
            {
                ServiceOperationResult response = await this.Client.Customers.DeleteCustomerAsync(customer).ConfigureAwait(false);

                ConsoleHelper.WriteInformationLine("Web API succeeded.");

                this.fieldLastCustomer = customer;
            }
            catch (ServiceException ex)
            {
                this.WriteServiceException(ex);
            }
            catch (Exception ex)
            {
                ConsoleHelper.WriteErrorLine(ex);
            }
        }

        #endregion

        #endregion
    }
}
