﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.DependencyInjection;
using Primavera.Hydrogen;
using Primavera.Hydrogen.AspNetCore.Webhooks;
using Primavera.Hydrogen.Rest;
using Primavera.Lithium.WebhooksPublisher.Models;
using Primavera.Lithium.WebhooksPublisher.Models.Metadata;

namespace Primavera.Lithium.WebhooksPublisher.WebApi.Controllers
{
    [SuppressMessage("StyleCop.CSharp.DocumentationRules", "SA1601:Partial elements should be documented")]
    public partial class CustomersController
    {
        #region Private Properties

        private IDistributedCache Cache
        {
            get
            {
                return this.HttpContext.RequestServices.GetRequiredService<IDistributedCache>();
            }
        }

        private IWebhooksService WebhooksService
        {
            get
            {
                return this.HttpContext.RequestServices.GetRequiredService<IWebhooksService>();
            }
        }

        #endregion

        #region Protected Methods

        /// <inheritdoc />
        protected override async Task<IActionResult> CreateCustomerCoreAsync(CustomerData customer)
        {
            // Validation

            SmartGuard.NotNull(() => customer, customer);

            // Exists?

            string item = await this.Cache.GetStringAsync($"C-{customer.Customer}").ConfigureAwait(false);
            if (item != null)
            {
                return this.Conflict(
                    new ServiceError("CustomerAlreadyExists", "The specified customer already exists."));
            }

            // Add

            await this.Cache.SetStringAsync(
                $"C-{customer}", 
                customer.Customer, 
                new DistributedCacheEntryOptions()
                {
                    AbsoluteExpirationRelativeToNow = TimeSpan.FromHours(1)
                })
                .ConfigureAwait(false);

            // ***
            // Webhook

            await this.WebhooksService.PublishEventAsync<CustomerPayload>(
                "Customer_Created",
                new CustomerPayload()
                {
                    Customer = customer.Customer
                })
                .ConfigureAwait(false);

            // Created

            string baseUri = string.Concat(this.HttpContext.Request.Scheme, "://", this.HttpContext.Request.Host.ToUriComponent());

            return this.Created(
                Routes.Instance.Resolve(
                    new Uri(baseUri), 
                    Routes.Customers.GetCustomer, 
                    new Dictionary<string, object>()
                    {
                        ["apiVersion"] = ApiVersions.Literals.DefaultVersionLiteral,
                        ["customer"] = customer
                    }), 
                customer);
        }

        /// <inheritdoc />
        protected override async Task<IActionResult> GetCustomerCoreAsync(string customer)
        {
            // Exists?

            string item = await this.Cache.GetStringAsync($"C-{customer}").ConfigureAwait(false);
            if (item == null)
            {
                return this.NotFound(
                    new ServiceError("CustomerNotFound", "The specified customer does not exist."));
            }

            // OK

            return this.Ok(item);
        }

        /// <inheritdoc />
        protected override async Task<IActionResult> DeleteCustomerCoreAsync(string customer)
        {
            // Exists?

            string item = await this.Cache.GetStringAsync($"C-{customer}").ConfigureAwait(false);
            if (item == null)
            {
                return this.NotFound(
                    new ServiceError("CustomerNotFound", "The specified customer does not exist."));
            }

            // Delete

            await this.Cache.RemoveAsync($"C-{customer}").ConfigureAwait(false);

            // NoContent

            return this.NoContent();
        }

        #endregion
    }
}
