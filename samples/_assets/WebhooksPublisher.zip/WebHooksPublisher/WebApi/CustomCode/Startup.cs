﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using Microsoft.Extensions.DependencyInjection;
using Primavera.Hydrogen.AspNetCore.Webhooks;
using Primavera.Lithium.WebhooksPublisher.WebApi.Configuration;

namespace Primavera.Lithium.WebhooksPublisher.WebApi
{
    [SuppressMessage("StyleCop.CSharp.DocumentationRules", "SA1601:Partial elements should be documented")]
    public partial class Startup
    {
        #region Protected Methods

        /// <inheritdoc />
        protected override void AddAdditionalServices(IServiceCollection services, HostConfiguration hostConfiguration)
        {
            // Default behavior

            base.AddAdditionalServices(services, hostConfiguration);

            // Add webhooks

            services.AddWebhooks(
               (options) =>
               {
                   options.ApplicationName = "WHP";

                   options.Events = new List<WebhookEvent>()
                   {
                       new WebhookEvent()
                       {
                           EventName = "Customer_Created",
                           EventDescriptions = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
                           {
                               ["en"] = "Raised when a new customer is created.",
                               ["pt"] = "Gerado quando um novo cliente é criado.",
                               ["es"] = "Criado cuando se crea un nuevo cliente.",
                           },
                           PayloadDescriptions = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
                           {
                               ["en"] = "The customer identifier.",
                               ["pt"] = "O identificador do cliente.",
                               ["es"] = "El identificador del cliente.",
                           }
                       },
                       new WebhookEvent()
                       {
                           EventName = "Customer_Updated",
                           EventDescriptions = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
                           {
                               ["en"] = "Raised when a customer is updated.",
                               ["pt"] = "Gerado quando um cliente é atualizado.",
                               ["es"] = "Criado cuando se modifica un nuevo cliente.",
                           },
                           PayloadDescriptions = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
                           {
                               ["en"] = "The customer identifier.",
                               ["pt"] = "O identificador do cliente.",
                               ["es"] = "El identificador del cliente.",
                           }
                       },
                       new WebhookEvent()
                       {
                           EventName = "Customer_Deleted",
                           EventDescriptions = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
                           {
                               ["en"] = "Raised when a customer is deleted.",
                               ["pt"] = "Gerado quando um cliente é eliminado.",
                               ["es"] = "Criado cuando se elimina un nuevo cliente.",
                           },
                           PayloadDescriptions = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
                           {
                               ["en"] = "The customer identifier.",
                               ["pt"] = "O identificador do cliente.",
                               ["es"] = "El identificador del cliente.",
                           }
                       }
                   };
               });
        }

        #endregion
    }
}
