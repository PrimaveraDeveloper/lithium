﻿# <a name="root"></a>PRIMAVERA Lithium Webhooks Publisher Service (WHP) Client Library

Provides a testing environment for developing the WebHooks infrastructure on Lithium.

## Service Client

| Class | Description |
| - | - |
| [`WebhooksPublisherClient`](#WebhooksPublisherClient) | The entry point of the Webhooks Publisher Service client library. |

## Operations

| Class | Name | Description |
| - | - | - |
| [`Customers`](#CustomersOperations) | Customers | Provides operations on customers. |

## Models

| Class | Name | Description |
| - | - | - |
| [`CustomerData`](#CustomerData) | Customer Data | Describes a customer. |
| [`CustomerPayload`](#CustomerPayload) | Customer Payload | Describes the payload for webhooks on customers. |

## Enumerations

The client library has no enumerations.

## Reference

### Service Client Classes

#### <a name="WebhooksPublisherClient"></a>`WebhooksPublisherClient`

- Namespace: `Primavera.Lithium.WebhooksPublisher`
- Inheritance: `WebhooksPublisherClientBase` (`ServiceClient<WebhooksPublisherClientBase>`)

##### Constructors

###### WebhooksPublisherClient(Uri, ServiceClientCredentials)

| Parameter | Type | Description |
| - | - | - |
| `baseUri` | `Uri` | The base URI of the service. |
| `credentials` | `ServiceClientCredentials` | The credentials that should be used to access the service. |

###### WebhooksPublisherClient(Uri, ServiceClientCredentials, HttpMessageHandler)

| Parameter | Type | Description |
| - | - | - |
| `baseUri` | `Uri` | The base URI of the service. |
| `credentials` | `ServiceClientCredentials` | The credentials that should be used to access the service. |
| `handler` | `HttpMessageHandler` | The root message handler. |

###### WebhooksPublisherClient(Uri, ServiceClientCredentials, HttpMessageHandler, bool)

| Parameter | Type | Description |
| - | - | - |
| `baseUri` | `Uri` | The base URI of the service. |
| `credentials` | `ServiceClientCredentials` | The credentials that should be used to access the service. |
| `handler` | `HttpMessageHandler` | The root message handler. |
| `disposeHandler` | `bool` | True if the inner handler should be disposed of, false if the inner handler is intended to be reused. |

###### WebhooksPublisherClient(Uri, AuthenticationCallback)

| Parameter | Type | Description |
| - | - | - |
| `baseUri` | `Uri` | The base URI of the service. |
| `callback` | `AuthenticationCallback` | The callback that will be invoked during authentication to get the access token. |

###### WebhooksPublisherClient(Uri, AuthenticationCallback, HttpMessageHandler)

| Parameter | Type | Description |
| - | - | - |
| `baseUri` | `Uri` | The base URI of the service. |
| `callback` | `AuthenticationCallback` | The callback that will be invoked during authentication to get the access token. |
| `handler` | `HttpMessageHandler` | The root message handler. |

###### WebhooksPublisherClient(Uri, AuthenticationCallback, HttpMessageHandler, bool)

| Parameter | Type | Description |
| - | - | - |
| `baseUri` | `Uri` | The base URI of the service. |
| `callback` | `AuthenticationCallback` | The callback that will be invoked during authentication to get the access token. |
| `handler` | `HttpMessageHandler` | The root message handler. |
| `disposeHandler` | `bool` | True if the inner handler should be disposed of, false if the inner handler is intended to be reused. |

##### Properties

| Property | Type | Description |
| - | - | - |
| `AcceptLanguage` | `string` | Gets or sets the preferred language for the response. |

##### Methods

###### SetRetryPolicy(RetryPolicy

Sets the retry policy.

| Parameter | Type | Description |
| - | - | - |
| `retryPolicy` | `RetryPolicy` | The new retry policy. |

###### SetUserAgent(string, string, string

Sets the user agent header when making requests to the service.

| Parameter | Type | Description |
| - | - | - |
| `productName` | `string` | The product name. |
| `version` | `string` | The version. |
| `info` | `string` | Additional information. |

##### Example

```csharp
Uri address = new Uri("[service-address]");

using WebhooksPublisherClient client = new WebhooksPublisherClient(
    new Uri(address),
    ClientCredentials.NoCredentials);
```

[^ Back to top](#root)

### Operations Classes

#### <a name="CustomersOperations"></a>`CustomersOperations`

Provides operations on customers.

- Namespace: `Primavera.Lithium.WebhooksPublisher`
- Inheritance: `CustomersOperationsBase` (`ICustomersOperations`)

##### Methods

##### `CreateCustomerAsync()`

Creates the specified customer.

```csharp
public async Task<ServiceOperationResult<string>> CreateCustomerAsync(CustomerData customer, CancellationToken cancellationToken = default);

public ServiceOperationResult<string> CreateCustomer(CustomerData customer);
```

###### Parameters

| Parameter | Type | Description | Rules |
| - | - | - | - |
| `customer` | `CustomerData` | The customer that should be created. | Required.  |


###### Returns

| Return Type | Description |
| - | - | - | - |
| `string` | The customer identifier. |


###### Status Codes

| Status Code | Description |
| - | - | - | - |
| `HttpStatusCode.Created` | Success. |
| `HttpStatusCode.BadRequest` | Failure: the request is invalid.|
| `HttpStatusCode.Conflict` | Failure: conflict.|

> The operation will raise `ServiceException` for any failure status code. The exception may include a body with a `ServiceError` depending on the status code.


[^ Back to top](#root)

##### `DeleteCustomerAsync()`

Deletes the specified customer.

```csharp
public async Task<ServiceOperationResult> DeleteCustomerAsync(string customer, CancellationToken cancellationToken = default);

public ServiceOperationResult DeleteCustomer(string customer);
```

###### Parameters

| Parameter | Type | Description | Rules |
| - | - | - | - |
| `customer` | `string` | The customer that should be deleted. | Required.  |


###### Returns

| Return Type | Description |
| - | - | - | - |
| None | The operation has no return value. |


###### Status Codes

| Status Code | Description |
| - | - | - | - |
| `HttpStatusCode.NoContent` | Success. |
| `HttpStatusCode.BadRequest` | Failure: the request is invalid.|
| `HttpStatusCode.NotFound` | Failure: not found.|

> The operation will raise `ServiceException` for any failure status code. The exception may include a body with a `ServiceError` depending on the status code.


[^ Back to top](#root)

##### `GetCustomerAsync()`

Retrieves the specified customer.

```csharp
public async Task<ServiceOperationResult<CustomerData>> GetCustomerAsync(string customer, CancellationToken cancellationToken = default);

public ServiceOperationResult<CustomerData> GetCustomer(string customer);
```

###### Parameters

| Parameter | Type | Description | Rules |
| - | - | - | - |
| `customer` | `string` | The identifier of the customer that should be retrieved. | Required.  |


###### Returns

| Return Type | Description |
| - | - | - | - |
| `Primavera.Lithium.WebhooksPublisher.Models.CustomerData` | The customer retrieved. |


###### Status Codes

| Status Code | Description |
| - | - | - | - |
| `HttpStatusCode.Ok` | Success. |
| `HttpStatusCode.BadRequest` | Failure: the request is invalid.|
| `HttpStatusCode.NotFound` | Failure: not found.|

> The operation will raise `ServiceException` for any failure status code. The exception may include a body with a `ServiceError` depending on the status code.


[^ Back to top](#root)

### Models Classes

#### <a name="CustomerData"></a>`CustomerData`

Describes a customer.

- Namespace: `Primavera.Lithium.WebhooksPublisher.Models`
- Inheritance: `CustomerDataBase`

##### Properties

| Property | Type | Description | Rules |
| - | - | - | - |
| `Customer` | `string` | The customer identifier. | Required.  |

[^ Back to top](#root)

#### <a name="CustomerPayload"></a>`CustomerPayload`

Describes the payload for webhooks on customers.

- Namespace: `Primavera.Lithium.WebhooksPublisher.Models`
- Inheritance: `CustomerPayloadBase`

##### Properties

| Property | Type | Description | Rules |
| - | - | - | - |
| `Customer` | `string` | The customer identifier. | Required.  |

[^ Back to top](#root)

