﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;

namespace Primavera.Lithium.EventBusSubscriber.Client.Console
{
    [SuppressMessage("StyleCop.CSharp.DocumentationRules", "SA1601:Partial elements should be documented")]
    internal partial class Application
    {
        #region Protected Methods

        /// <inheritdoc />
        protected override void PrintCustomMenuOptions()
        {
        }

        /// <inheritdoc />
        protected override Task<bool> HandleCustomMenuOptionsAsync(ConsoleKeyInfo key)
        {
            return Task.FromResult(true);
        }

        #endregion
    }
}
