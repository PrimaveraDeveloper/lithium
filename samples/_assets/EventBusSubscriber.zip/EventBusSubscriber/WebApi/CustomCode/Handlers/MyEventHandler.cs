﻿using System;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Primavera.Hydrogen;
using Primavera.Hydrogen.EventBus.Contracts;

namespace Primavera.Lithium.EventBusSubscriber.WebApi.Handlers
{
    /// <summary>
    /// Defines an handler for an event from Event Bus.
    /// </summary>
    /// <seealso cref="IEventBusEventHandler{T}" />
    internal partial class MyEventHandler : IEventBusEventHandler<string>
    {
        #region Private Properties

        private IServiceProvider ServiceProvider
        {
            get;
        }

        private ILogger Logger
        {
            get
            {
                return this.ServiceProvider.GetRequiredService<ILogger<MyEventHandler>>();
            }
        }

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="MyEventHandler"/> class.
        /// </summary>
        /// <param name="serviceProvider">The service provider.</param>
        public MyEventHandler(IServiceProvider serviceProvider)
        {
            // Validation

            SmartGuard.NotNull(() => serviceProvider, serviceProvider);

            // Set properties

            this.ServiceProvider = serviceProvider;
        }

        #endregion

        #region Public Methods

        /// <inheritdoc />
        public Task<bool> HandleAsync(IEventBusEvent<string> eventBusEvent)
        {
            // Event received

            this.Logger.LogDebug($"Event received: {eventBusEvent.Body}.");

            // Handled

            return Task.FromResult(true);
        }

        #endregion
    }
}
