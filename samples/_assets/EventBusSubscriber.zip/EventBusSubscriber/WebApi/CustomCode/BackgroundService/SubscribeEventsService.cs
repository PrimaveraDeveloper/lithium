﻿using System.Diagnostics.CodeAnalysis;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using Primavera.Hydrogen.EventBus.Contracts;
using Primavera.Lithium.EventBusSubscriber.WebApi.Handlers;

namespace Primavera.Lithium.EventBusSubscriber.WebApi.BackgroundServices
{
    [SuppressMessage("StyleCop.CSharp.DocumentationRules", "SA1601:Partial elements should be documented")]
    internal partial class SubscribeEventsService
    {
        #region Private Properties

        private IEventBusService EventBusService
        {
            get
            {
                return this.ServiceProvider.GetRequiredService<IEventBusService>();
            }
        }

        #endregion

        #region Protected Methods

        /// <inheritdoc />
        protected override async Task ExecuteAsync(CancellationToken cancellationToken)
        {
            // Subscribe events

            IEventBusEventHandler<string> handler = new MyEventHandler(this.ServiceProvider);

            await this.EventBusService
                .SubscribeAsync("sample", handler)
                .ConfigureAwait(false);
        }

        #endregion
    }
}
