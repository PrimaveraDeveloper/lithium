﻿using System.Diagnostics.CodeAnalysis;
using Microsoft.Extensions.DependencyInjection;
using Primavera.Hydrogen.EventBus.Azure;
using Primavera.Lithium.EventBusSubscriber.WebApi.Configuration;

namespace Primavera.Lithium.EventBusSubscriber.WebApi
{
    [SuppressMessage("StyleCop.CSharp.DocumentationRules", "SA1601:Partial elements should be documented")]
    public partial class Startup
    {
        #region Protected Methods

        /// <inheritdoc />
        protected override HostConfiguration AddConfiguration(IServiceCollection services)
        {
            // Default behavior

            HostConfiguration hostConfiguration = base.AddConfiguration(services);

            // Register Event Bus configuration

            services.Configure<AzureEventBusOptions>(
                this.Configuration.GetSection(nameof(AzureEventBusOptions)));

            // Result

            return hostConfiguration;
        }

        /// <inheritdoc />
        protected override void AddAdditionalServices(IServiceCollection services, HostConfiguration hostConfiguration)
        {
            // Default behavior

            base.AddAdditionalServices(services, hostConfiguration);

            // Register Event Bus

            services.AddAzureEventBus();
        }

        #endregion
    }
}
