﻿using System.Diagnostics.CodeAnalysis;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Primavera.Hydrogen.EventBus;

namespace Primavera.Lithium.EventBusSubscriber.WebApi.BackgroundServices
{
    [SuppressMessage("StyleCop.CSharp.DocumentationRules", "SA1601:Partial elements should be documented")]
    internal partial class SubscribeEventsService
    {
        #region Protected Property

        /// <inheritdoc />
        protected override bool HandleExceptions => true;

        #endregion

        #region Private Properties

        private IEventBusService EventBusService
        {
            get
            {
                return this.ServiceProvider.GetRequiredService<IEventBusService>();
            }
        }

        #endregion

        #region Protected Methods

        /// <inheritdoc />
        protected override async Task ExecuteAsync(CancellationToken cancellationToken)
        {
            // Subscribe events

            EventBusHandlerDelegate<string> handler = this.HandleAsync;

            await this.EventBusService
                .SubscribeAsync("sample", "sample", handler, cancellationToken)
                .ConfigureAwait(false);
        }

        #endregion

        #region Private Methods

        private Task<bool> HandleAsync(IEventBusEvent<string> eventBusEvent)
        {
            // Event received

            this.Logger.LogInformation($"Event received: {eventBusEvent.Body}.");

            // Handled

            return Task.FromResult(true);
        }

        #endregion
    }
}
