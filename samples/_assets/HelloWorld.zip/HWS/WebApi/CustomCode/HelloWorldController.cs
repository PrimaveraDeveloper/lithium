﻿using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace Primavera.Lithium.Helloworld.WebApi.Controllers
{
    [SuppressMessage("StyleCop:DocumentationRules", "SA1601:PartialElementsMustBeDocumented")]
    public partial class HelloWorldController
    {
        #region Protected Methods

        /// <inheritdoc />
        protected override Task<IActionResult> GetHelloWorldCoreAsync(string inputName)
        {
            return Task.FromResult<IActionResult>(
                this.Ok($"Hello {inputName}!"));
        }

        #endregion
    }
}
