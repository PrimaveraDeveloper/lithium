﻿using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace Primavera.Lithium.Helloworld.WebApi.Controllers
{
    [SuppressMessage("StyleCop:DocumentationRules", "SA1601:PartialElementsMustBeDocumented")]
    public partial class MonitoringController
    {
        #region Protected Methods

        /// <inheritdoc />
        public override Task<IActionResult> ProbeAsync()
        {
            return Task.FromResult<IActionResult>(this.Ok("OK"));
        }

        /// <inheritdoc />
        public override Task<IActionResult> DiagnosticsAsync()
        {
            return this.ProbeAsync();
        }

        #endregion
    }
}
