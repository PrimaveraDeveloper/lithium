﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using Primavera.Hydrogen;
using Primavera.Hydrogen.Rest.Client;

namespace Primavera.Lithium.Helloworld.Client.Console
{
    [SuppressMessage("StyleCop:DocumentationRules", "SA1601:PartialElementsMustBeDocumented")]
    internal sealed partial class Application
    {
        #region Protected Methods

        /// <inheritdoc />
        protected override void PrintCustomMenuOptions()
        {
            ConsoleHelper.WriteLine("1. Hello World.");
        }

        /// <inheritdoc />
        protected override async Task<bool> HandleCustomMenuOptionsAsync(ConsoleKeyInfo key)
        {
            switch (key.Key)
            {
                case ConsoleKey.D1:
                case ConsoleKey.NumPad1:
                    return !await this.ShowHelloWorldMenuAsync().ConfigureAwait(false);
                default:
                    return true;
            }
        }

        #endregion

        #region Private Methods

        #region Menus

        private async Task<bool> ShowHelloWorldMenuAsync()
        {
            // Menu

            bool terminate = false;
            bool cont = true;
            while (cont)
            {
                ConsoleHelper.WriteLine();
                ConsoleHelper.WriteLine("========================================");
                ConsoleHelper.WriteLine("Hello World Menu");
                ConsoleHelper.WriteLine("========================================");
                ConsoleHelper.WriteLine();
                ConsoleHelper.WriteLine("1. Get Hello World.");
                ConsoleHelper.WriteLine("<. Back.");
                ConsoleHelper.WriteLine("Q. Quit.");
                ConsoleHelper.Write(">> ");

                ConsoleKeyInfo key = ConsoleHelper.ReadKey();
                ConsoleHelper.WriteLine();

                switch (key.Key)
                {
                    case ConsoleKey.Q:
                        cont = false;
                        terminate = true;
                        break;
                    case ConsoleKey.LeftArrow:
                        cont = false;
                        break;
                    case ConsoleKey.D1:
                    case ConsoleKey.NumPad1:
                        await this.GetHelloWorldAsync().ConfigureAwait(false);
                        break;
                    default:
                        break;
                }
            }

            // Result

            return terminate;
        }

        #endregion

        [SuppressMessage("Design", "CA1031:Do not catch general exception types", Justification = "Want to print all exceptions.")]
        private async Task GetHelloWorldAsync()
        {
            ConsoleHelper.WriteLine();
            ConsoleHelper.WriteLine();

            // Get the parameters

            string inputName = this.GetValueString("input name");

            // Call the Web API

            ConsoleHelper.WriteLine();
            ConsoleHelper.WriteInformationLine("Calling the Web API...");

            try
            {
                ServiceOperationResult<string> response = await this.Client.HelloWorld.GetHelloWorldAsync(inputName).ConfigureAwait(false);

                ConsoleHelper.WriteInformationLine("Web API call succeeded.");
                ConsoleHelper.WriteInformationLine(response.Body);
            }
            catch (ServiceException ex)
            {
                this.WriteServiceException(ex);
            }
            catch (Exception ex)
            {
                ConsoleHelper.WriteErrorLine(ex);
            }
        }

        #endregion
    }
}
